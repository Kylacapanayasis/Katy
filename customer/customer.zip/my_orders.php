<center>
    <h1>My Orders</h1>
    <p class="lead">Your orders in one place</p>
    <p class="text-muted">
        If you have any questions, feel free to <a href="../contact.php">Contact Us</a>. Our Customer Service works <strong>between 7:00 am - 6:00 pm</strong>
    </p>
</center>

<hr>

<div class="table-responsive">
    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>ON:</th>
                <th>Invoice</th>
                <th>Product Name</th>
                <th>Order Date</th>
                <th>Qty</th>
                <th>Roast Type</th>
                <th>Coffee Beans</th>
                <th>Total</th>
                <th>Paid/Unpaid</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php
            // Fetch customer details
            $customer_session = $_SESSION['customer_email'];
            $get_customer = "SELECT customer_id FROM customers WHERE customer_email='$customer_session'";
            $run_customer = mysqli_query($con, $get_customer);
            $row_customer = mysqli_fetch_array($run_customer);
            $customer_id = $row_customer['customer_id'];

            // Fetch orders with aggregated data
            $get_orders = "
            SELECT 
                co.invoice_no, 
                SUM(co.due_amount) AS total_amount, 
                SUM(co.qty) AS total_qty,
                MAX(co.order_date) AS order_date, 
                MAX(co.order_status) AS order_status,
                MAX(co.payment_method) AS payment_method, 
                MAX(co.size) AS size,
                MAX(co.roast) AS roast,
                MAX(co.coffee) AS coffee,
                p.product_title AS product_name
            FROM 
                customer_orders AS co
            JOIN 
                products AS p ON co.product_id = p.product_id
            WHERE 
                co.customer_id='$customer_id' 
            GROUP BY 
                co.invoice_no";
        
            $run_orders = mysqli_query($con, $get_orders);

            // Error handling for the query
            if (!$run_orders) {
                echo "Error: " . mysqli_error($con);
                exit(); // Stop execution if there's an error
            }

            if (mysqli_num_rows($run_orders) == 0) {
                echo "<tr><td colspan='10' class='text-center'>No orders found.</td></tr>";
            } else {
                $i = 0;
                while ($row_orders = mysqli_fetch_array($run_orders)) {
                    $invoice_no = $row_orders['invoice_no'];
                    $total_amount = $row_orders['total_amount'];
                    $total_qty = $row_orders['total_qty'];
                    $roast = $row_orders['roast'];
                    $coffee = $row_orders['coffee'];
                    $order_date = substr($row_orders['order_date'], 0, 11);
                    $order_status = $row_orders['order_status'];
                    $method = $row_orders['payment_method'];
                    $product_name = $row_orders['product_name'];

                    // Define the order status display
                    $order_status_display = ($order_status == 'pending') ? 'Pending Approval' : 
                                            (($order_status == 'Complete') ? 'Paid' : 'Unpaid');

                    $i++;
        ?>
            <tr>
                <td><?php echo $i; ?></td>
                <td><?php echo $invoice_no; ?></td>
                <td><?php echo $product_name; ?></td>
                <td><?php echo $order_date; ?></td>
                <td><?php echo $total_qty; ?></td>
                <td><?php echo $roast; ?></td>
                <td><?php echo $coffee; ?></td>
                <td>₱<?php echo number_format($total_amount, 2); ?></td>
                <td><?php echo $order_status_display; ?></td>
                <td><?php echo $order_status; ?></td>
            </tr>
        <?php 
                }
            }
        ?>
        </tbody>
    </table>
</div>

<div class="text-center">
    <button type="button" class="btn btn-primary btn-rounded" onclick="redirectToReceipt()">Receipt</button>
</div>

<script>
    function redirectToReceipt() {
        window.location.href = 'receipt.php';
    }
</script>
