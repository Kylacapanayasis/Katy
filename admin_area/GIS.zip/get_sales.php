<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to the database
$host = 'localhost';
$username = 'root'; // Replace with your database username
$password = ''; // Replace with your database password
$database = 'ecom_store'; // Replace with your database name

$conn = new mysqli($host, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to count sales per barangay and get the most bought product
$sql = "
    SELECT c.customer_address, p.product_title, COUNT(o.product_id) as product_count, COUNT(o.customer_id) as sales_count
    FROM customers c
    JOIN pending_orders o ON c.customer_id = o.customer_id
    JOIN products p ON o.product_id = p.product_id
    WHERE o.order_status = 'complete' -- Assuming 'complete' indicates a completed sale
    GROUP BY c.customer_address, o.product_id
";

// Fetch data
$result = $conn->query($sql);

$sales_data = array();

// Process the results
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Extract the barangay name from the address (you can adapt this as necessary)
        foreach (['Anos', 'Bagong Silang', 'Bambang', 'Batong Malake', 'Baybayin', 'Bayog', 'Lalakay', 'Maahas', 'Malinta', 'Mayondon', 'Putho-Tuntungin', 'San Antonio', 'Tadlac', 'Timugan'] as $barangay) {
            if (strpos($row['customer_address'], $barangay) !== false) {
                if (!isset($sales_data[$barangay])) {
                    $sales_data[$barangay] = ['sales_count' => 0, 'most_bought_product' => '', 'most_bought_count' => 0];
                }
                // Update sales count
                $sales_data[$barangay]['sales_count'] += $row['sales_count'];

                // Check for most bought product
                if ($row['product_count'] > $sales_data[$barangay]['most_bought_count']) {
                    $sales_data[$barangay]['most_bought_product'] = $row['product_title'];
                    $sales_data[$barangay]['most_bought_count'] = $row['product_count'];
                }
                break;
            }
        }
    }
}

// Return the sales data as JSON
header('Content-Type: application/json');
echo json_encode($sales_data);

$conn->close();
?>
