// Initialize the map centered on Los Baños, Laguna
var map = L.map('map').setView([14.1709, 121.244], 13); // Coordinates for Los Baños

// Set LatLng bounds for Los Baños
var bounds = [
    [14.100, 121.180], // Southwest corner
    [14.240, 121.300]  // Northeast corner
];

// Add the max bounds to restrict the view
map.setMaxBounds(bounds);

// Set the zoom limits
map.setMinZoom(13); // Prevent zooming out too far
map.setMaxZoom(18); // Prevent zooming in too far

// Add OpenStreetMap tiles to the map
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

// Barangay coordinates (updated with correct coordinates)
var barangays = {
    'Anos': [14.181238, 121.232267],
    'Bagong Silang': [14.11931, 121.22357],
    'Bambang': [14.177922, 121.218284],
    'Batong Malake': [14.16713, 121.24340],
    'Baybayin': [14.181590, 121.224282],
    'Bayog': [14.19038, 121.24417],
    'Lalakay': [14.17282, 121.21426],
    'Maahas': [14.17611, 121.25731],
    'Malinta': [14.18574, 121.23029],
    'Mayondon': [14.191122, 121.236365],
    'Putho-Tuntungin': [14.15152, 121.25267],
    'San Antonio': [14.17715, 121.24722],
    'Tadlac': [14.17932, 121.20945],
    'Timugan': [14.17885, 121.22443]
};

// Fetch sales data from the PHP script
fetch('get_sales.php')
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok: ' + response.statusText);
        }
        return response.json();
    })
    .then(data => {
        for (var barangay in barangays) {
            var sales = data[barangay] ? data[barangay].sales_count : 0; // Default to 0 if no sales for a barangay
            var mostBoughtProduct = data[barangay] ? data[barangay].most_bought_product : 'None'; // Default to 'None' if no product

            // Add a marker for each barangay and display the sales and most bought product in a popup
            L.marker(barangays[barangay]).addTo(map)
                .bindPopup(barangay + ': ' + sales + ' sales, Most Bought Product: ' + mostBoughtProduct);
        }
    })
    .catch(error => console.error('Error fetching sales data:', error));
