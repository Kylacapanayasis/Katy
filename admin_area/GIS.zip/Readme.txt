Paste it in Admin area my nigga then goods na
